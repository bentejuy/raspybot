Multipurpose library oriented to the Raspberry Pi for managing
devices that interact with the GPIO channels.

-------------------------------------

 - This version requires Python 2.7 or later.
 - Depends on Python Modules :
    RPi Module -> https://pypi.python.org/pypi/RPi.GPIO


